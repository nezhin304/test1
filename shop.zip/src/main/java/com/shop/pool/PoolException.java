package com.shop.pool;

public class PoolException extends RuntimeException {

    public  PoolException(String message, Throwable cause) {
        super(message, cause);
    }
}
